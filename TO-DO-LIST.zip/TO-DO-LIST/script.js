let list = document.getElementById("list-container");
let input_box = document.getElementById("input-box");

function addTask() {
    if(input_box.value === ''){
        alert('Add your tast')
    }else{
        let task = document.createElement('li');
        task.textContent = input_box.value
        list.appendChild(task)

        let span = document.createElement('span');
        span.textContent = '\u00d7';
        task.appendChild(span)
    }
    input_box.value = ''
    saveData()
}

list.addEventListener('click', (el) =>{
    if(el.target.tagName == 'LI'){
        el.target.classList.toggle('checked')
        saveData()
    }else if(el.target.tagName == 'SPAN'){
        el.target.parentElement.remove()
        saveData()
    }
})

function saveData(){
    localStorage.setItem('tasks', list.innerHTML);
}

function showData(){
    list.innerHTML = localStorage.getItem('tasks')
}

showData()
